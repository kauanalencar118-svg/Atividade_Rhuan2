<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\ClienteController;
use App\Http\Controllers\TarefaController;

Route::get('/', function () {
    return view('pages.dashboard');
});

//Route::middleware(['auth'])->group(function (){
    Route::resource('clientes', ClienteController::class);
//});

Route::resource('tarefas', TarefaController::class);


require __DIR__.'/auth.php';
