<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Tarefa extends Model
{
    protected $fillable = [
        'titulo',
        'descricao',
        'status',
        'prioridade',
        'data_limite',
    ];

    protected $casts = [
        'data_limite' => 'date',
    ];

    /**
     * Retorna o label formatado do status
     */
    public function getStatusLabelAttribute(): string
    {
        return match($this->status) {
            'pendente'    => 'Pendente',
            'em_andamento'=> 'Em Andamento',
            'concluida'   => 'Concluída',
            default       => ucfirst($this->status),
        };
    }

    /**
     * Retorna a classe Bootstrap badge do status
     */
    public function getStatusBadgeAttribute(): string
    {
        return match($this->status) {
            'pendente'    => 'secondary',
            'em_andamento'=> 'primary',
            'concluida'   => 'success',
            default       => 'secondary',
        };
    }

    /**
     * Retorna o label formatado da prioridade
     */
    public function getPrioridadeLabelAttribute(): string
    {
        return match($this->prioridade) {
            'baixa' => 'Baixa',
            'media' => 'Média',
            'alta'  => 'Alta',
            default => ucfirst($this->prioridade),
        };
    }

    /**
     * Retorna a classe Bootstrap badge da prioridade
     */
    public function getPrioridadeBadgeAttribute(): string
    {
        return match($this->prioridade) {
            'baixa' => 'success',
            'media' => 'warning',
            'alta'  => 'danger',
            default => 'secondary',
        };
    }
}
