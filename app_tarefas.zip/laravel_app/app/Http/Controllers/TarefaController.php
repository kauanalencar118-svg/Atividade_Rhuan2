<?php

namespace App\Http\Controllers;

use App\Models\Tarefa;
use Illuminate\Http\Request;

class TarefaController extends Controller
{
    /**
     * Lista todas as tarefas, com filtro opcional por status.
     */
    public function index(Request $request)
    {
        $query = Tarefa::latest();

        if ($request->filled('status')) {
            $query->where('status', $request->status);
        }

        $tarefas = $query->get();
        $statusSelecionado = $request->status;

        return view('tarefas.index', compact('tarefas', 'statusSelecionado'));
    }

    /**
     * Exibe o formulário de criação de uma nova tarefa.
     */
    public function create()
    {
        return view('tarefas.create');
    }

    /**
     * Salva uma nova tarefa no banco de dados.
     */
    public function store(Request $request)
    {
        $request->validate([
            'titulo'      => 'required|min:3|max:255',
            'descricao'   => 'nullable|string',
            'status'      => 'required|in:pendente,em_andamento,concluida',
            'prioridade'  => 'required|in:baixa,media,alta',
            'data_limite' => 'nullable|date',
        ], [
            'titulo.required'     => 'O título é obrigatório.',
            'titulo.min'          => 'O título deve ter no mínimo 3 caracteres.',
            'status.required'     => 'O status é obrigatório.',
            'status.in'           => 'O status informado não é válido.',
            'prioridade.required' => 'A prioridade é obrigatória.',
            'prioridade.in'       => 'A prioridade informada não é válida.',
            'data_limite.date'    => 'A data limite deve ser uma data válida.',
        ]);

        Tarefa::create($request->only(['titulo', 'descricao', 'status', 'prioridade', 'data_limite']));

        return redirect()->route('tarefas.index')
            ->with('success', 'Tarefa criada com sucesso!');
    }

    /**
     * Exibe o formulário de edição de uma tarefa.
     */
    public function edit($id)
    {
        $tarefa = Tarefa::findOrFail($id);
        return view('tarefas.edit', compact('tarefa'));
    }

    /**
     * Atualiza uma tarefa existente.
     */
    public function update(Request $request, $id)
    {
        $tarefa = Tarefa::findOrFail($id);

        $request->validate([
            'titulo'      => 'required|min:3|max:255',
            'descricao'   => 'nullable|string',
            'status'      => 'required|in:pendente,em_andamento,concluida',
            'prioridade'  => 'required|in:baixa,media,alta',
            'data_limite' => 'nullable|date',
        ], [
            'titulo.required'     => 'O título é obrigatório.',
            'titulo.min'          => 'O título deve ter no mínimo 3 caracteres.',
            'status.required'     => 'O status é obrigatório.',
            'status.in'           => 'O status informado não é válido.',
            'prioridade.required' => 'A prioridade é obrigatória.',
            'prioridade.in'       => 'A prioridade informada não é válida.',
            'data_limite.date'    => 'A data limite deve ser uma data válida.',
        ]);

        $tarefa->update($request->only(['titulo', 'descricao', 'status', 'prioridade', 'data_limite']));

        return redirect()->route('tarefas.index')
            ->with('success', 'Tarefa atualizada com sucesso!');
    }

    /**
     * Exclui uma tarefa.
     */
    public function destroy($id)
    {
        Tarefa::destroy($id);

        return redirect()->route('tarefas.index')
            ->with('success', 'Tarefa excluída com sucesso!');
    }
}
