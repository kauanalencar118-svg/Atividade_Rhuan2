<h1>Cliente</h1>

<table border="1">
    <tr>
        <td>Nome</td>
        <td>Email</td>
        <td>telefone</td>
    </tr>
    <?php $__currentLoopData = $clientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cliente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($cliente->nome); ?></td>
            <td><?php echo e($cliente->email); ?></td>
            <td><?php echo e($cliente->telefone); ?></td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table><?php /**PATH C:\Users\diogo.muneratto\Desktop\aula\resources\views/clientes/index.blade.php ENDPATH**/ ?>