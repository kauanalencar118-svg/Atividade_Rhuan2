<h1>Novo Cliente</h1>

<form action="<?php echo e(route('clientes.store')); ?>" method="post">
    <?php echo csrf_field(); ?>
    <input type="text" name="nome"><br/>
    <input type="email" name="email"><br/>
    <input type="text" name="telefone"><br/>
    
    <button type="submit">Salvar</button>
</form><?php /**PATH C:\Users\diogo.muneratto\Downloads\aula\resources\views/clientes/create.blade.php ENDPATH**/ ?>