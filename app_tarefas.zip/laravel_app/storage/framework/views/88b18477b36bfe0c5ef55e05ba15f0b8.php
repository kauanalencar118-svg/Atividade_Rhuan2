

<?php $__env->startSection('content'); ?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h2>Cliente</h2>
    <a href="<?php echo e(route('clientes.create')); ?>" class="btn btn-primary"/>Novo</a>
</div>

<div class="card border-0 shadow-sm">
    <div class="card-body">
    <table class="table table-striped">
        <tr>
            <td>Nome</td>
            <td>Email</td>
            <td>telefone</td>
            <td width="180">Ação</td>
        </tr>
        <?php $__currentLoopData = $clientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cliente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($cliente->nome); ?></td>
                <td><?php echo e($cliente->email); ?></td>
                <td><?php echo e($cliente->telefone); ?></td>
                <td>
                    <a href="<?php echo e(route('clientes.edit', $cliente->id)); ?>" class="btn btn-warning btn-sm"/>Editar</a>

                    <form action="<?php echo e(route('clientes.destroy', $cliente->id)); ?>" method="POST" class="d-inline">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-danger btn-sm">Excluir</button>
                    </form>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
       <!-- <?php echo e($clientes->links()); ?> -->
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\diogo.muneratto\Downloads\bootstrap\resources\views/clientes/index.blade.php ENDPATH**/ ?>