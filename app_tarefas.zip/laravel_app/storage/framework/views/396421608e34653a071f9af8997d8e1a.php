

<?php $__env->startSection('content'); ?>

<div class="card border-0 shadow-sm">
    <div class="card-body">
    <h1 class="mb-4">Editar Cliente</h1>

    <form action="<?php echo e(route('clientes.update', $cliente->id)); ?>" method="post">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>   
        <div class="mb-3">
            <label>Nome</label>
            <input type="text" name="nome" class="form-control" value="<?php echo e($cliente->nome); ?>">
        </div>
        <div class="mb-3">
            <label>E-mail</label>
            <input type="email" name="email" class="form-control" value="<?php echo e($cliente->email); ?>">
        </div>
        <div class="mb-3">
            <label>Telefone</label>
            <input type="text" name="telefone" class="form-control" value="<?php echo e($cliente->telefone); ?>">
        </div>
        <button type="submit" class="btn btn-info">Atualizar</button>
    </form>

    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\diogo.muneratto\Downloads\bootstrap\resources\views/clientes/edit.blade.php ENDPATH**/ ?>