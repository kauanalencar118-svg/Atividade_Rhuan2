<h1>Cliente</h1>

<a href="<?php echo e(route('clientes.create')); ?>"/>Novo</a>

<table border="1">
    <tr>
        <td>Nome</td>
        <td>Email</td>
        <td>telefone</td>
        <td>Ação</td>
    </tr>
    <?php $__currentLoopData = $clientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cliente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($cliente->nome); ?></td>
            <td><?php echo e($cliente->email); ?></td>
            <td><?php echo e($cliente->telefone); ?></td>
            <td>
                <a href="<?php echo e(route('clientes.edit', $cliente->id)); ?>"/>Editar</a>

                <form action="<?php echo e(route('clientes.destroy', $cliente->id)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit">Excluir</button>
                </form>
            </td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table><?php /**PATH C:\Users\diogo.muneratto\Downloads\aula\resources\views/clientes/index.blade.php ENDPATH**/ ?>