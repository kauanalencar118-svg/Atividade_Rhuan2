<h1>Editar Cliente</h1>

<form action="<?php echo e(route('clientes.update', $cliente->id)); ?>" method="post">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>
    <input type="text" name="nome" value="<?php echo e($cliente->nome); ?>"><br/>
    <input type="email" name="email" value="<?php echo e($cliente->email); ?>"><br/>
    <input type="text" name="telefone" value="<?php echo e($cliente->telefone); ?>"><br/>
    
    <button type="submit">Editar</button>
</form><?php /**PATH C:\Users\diogo.muneratto\Downloads\aula\aula\resources\views/clientes/edit.blade.php ENDPATH**/ ?>