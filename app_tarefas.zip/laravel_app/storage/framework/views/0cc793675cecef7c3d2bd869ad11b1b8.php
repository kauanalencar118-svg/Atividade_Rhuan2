

<?php $__env->startSection('content'); ?>

    <h1>Novo Cliente</h1>

    <form action="<?php echo e(route('clientes.store')); ?>" method="post">
        <?php echo csrf_field(); ?>
        <input type="text" name="nome"><br/>
        <input type="email" name="email"><br/>
        <input type="text" name="telefone"><br/>
        
        <button type="submit">Salvar</button>
    </form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\diogo.muneratto\Downloads\routes\resources\views/clientes/create.blade.php ENDPATH**/ ?>