<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>App</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-sRIl4kxILFvY47J16cr9ZwB07vP4J8+LH7qKQnuqkuIAvNWLzeN8tE5YBujZqJLB" crossorigin="anonymous">
    <link rel="stylesheet" href="/global.css">
</head>
<body>

<div class="d-flex">
    <div class="bg-dark text-white p-3" style="width:250px; min-height:100vh;">
        <h3>CRM</h3>
        <hr/>
        <ul class="nav flex-column">
            <li class="nav-item mb-2">
                <a href="/" class="nav-link text-white">Dashboard</a>
            </li>
            <li class="nav-item mb-2">
                <a href="{{ route('clientes.index') }}" class="nav-link text-white">Clientes</a>
            </li>
            <li class="nav-item mb-2">
                <a href="{{ route('tarefas.index') }}" class="nav-link text-white">Tarefas</a>
            </li>
        </ul>
    </div>

    <div class="flex-grow-1">
        <nav class="navbar navbar-expand-lg navbar-light bg-light px-4 shadow-sm">
            <div class="container-fluid">
                <span class="navbar-brand">Painel Admin</span>
                <div class="d-flex align-items-center gap-3">
                    <span>Autor</span>
                </div>
            </div>
        </nav>
        <div class="p-4">
            @yield('content')
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js" integrity="sha384-FKyoEForCGlyvwx9Hj09JcYn3nv7wiPVlz7YYwJrWVcXK/BmnVDxM+D2scQbITxI" crossorigin="anonymous"></script>
</body>
</html>
