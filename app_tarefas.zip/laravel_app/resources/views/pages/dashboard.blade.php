@extends('layouts.app')

@section('content')
    <div class="row g-4">
        <div class="col-md-4">
            <div class="card shadow-sm border-0">
                <div class="card-body">
                    <h5>Total Clientes</h5>
                    <h2>1.000</h2>
                </div>
            </div>
        </div>

        <div class="col-md-4">
            <div class="card shadow-sm border-0">
                <div class="card-body">
                    <h5>Total Clientes</h5>
                    <h2>1.000</h2>
                </div>
            </div>
        </div>

        <div class="col-md-4">
            <div class="card shadow-sm border-0">
                <div class="card-body">
                    <h5>Total Clientes</h5>
                    <h2>1.000</h2>
                </div>
            </div>
        </div>
    </div>
@endsection