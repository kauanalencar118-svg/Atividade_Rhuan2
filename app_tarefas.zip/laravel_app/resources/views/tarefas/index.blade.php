@extends('layouts.app')

@section('content')

<div class="d-flex justify-content-between align-items-center mb-4">
    <h2>Tarefas</h2>
    <a href="{{ route('tarefas.create') }}" class="btn btn-primary">+ Nova Tarefa</a>
</div>

{{-- Mensagem de sucesso --}}
@if(session('success'))
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        {{ session('success') }}
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Fechar"></button>
    </div>
@endif

{{-- Filtro por Status --}}
<div class="card border-0 shadow-sm mb-4">
    <div class="card-body py-3">
        <form method="GET" action="{{ route('tarefas.index') }}" class="d-flex align-items-center gap-3">
            <label for="status" class="form-label mb-0 fw-semibold">Filtrar por Status:</label>
            <select name="status" id="status" class="form-select w-auto" onchange="this.form.submit()">
                <option value="">Todos</option>
                <option value="pendente"    {{ $statusSelecionado === 'pendente'     ? 'selected' : '' }}>Pendente</option>
                <option value="em_andamento"{{ $statusSelecionado === 'em_andamento' ? 'selected' : '' }}>Em Andamento</option>
                <option value="concluida"  {{ $statusSelecionado === 'concluida'    ? 'selected' : '' }}>Concluída</option>
            </select>
            @if($statusSelecionado)
                <a href="{{ route('tarefas.index') }}" class="btn btn-outline-secondary btn-sm">Limpar filtro</a>
            @endif
        </form>
    </div>
</div>

{{-- Tabela de Tarefas --}}
<div class="card border-0 shadow-sm">
    <div class="card-body">
        @if($tarefas->isEmpty())
            <div class="text-center py-5 text-muted">
                <p class="fs-5">Nenhuma tarefa encontrada.</p>
                <a href="{{ route('tarefas.create') }}" class="btn btn-primary">Criar primeira tarefa</a>
            </div>
        @else
        <table class="table table-striped table-hover align-middle">
            <thead class="table-dark">
                <tr>
                    <th>#</th>
                    <th>Título</th>
                    <th>Descrição</th>
                    <th>Status</th>
                    <th>Prioridade</th>
                    <th>Data Limite</th>
                    <th>Criado em</th>
                    <th width="160">Ações</th>
                </tr>
            </thead>
            <tbody>
                @foreach($tarefas as $tarefa)
                <tr>
                    <td>{{ $tarefa->id }}</td>
                    <td class="fw-semibold">{{ $tarefa->titulo }}</td>
                    <td>
                        @if($tarefa->descricao)
                            <span class="text-muted" style="max-width:200px; display:inline-block; white-space:nowrap; overflow:hidden; text-overflow:ellipsis;">
                                {{ $tarefa->descricao }}
                            </span>
                        @else
                            <span class="text-muted fst-italic">—</span>
                        @endif
                    </td>
                    <td>
                        <span class="badge bg-{{ $tarefa->statusBadge }}">
                            {{ $tarefa->statusLabel }}
                        </span>
                    </td>
                    <td>
                        <span class="badge bg-{{ $tarefa->prioridadeBadge }}">
                            {{ $tarefa->prioridadeLabel }}
                        </span>
                    </td>
                    <td>
                        @if($tarefa->data_limite)
                            {{ $tarefa->data_limite->format('d/m/Y') }}
                        @else
                            <span class="text-muted fst-italic">—</span>
                        @endif
                    </td>
                    <td>{{ $tarefa->created_at->format('d/m/Y') }}</td>
                    <td>
                        <a href="{{ route('tarefas.edit', $tarefa->id) }}" class="btn btn-warning btn-sm">Editar</a>

                        <form action="{{ route('tarefas.destroy', $tarefa->id) }}" method="POST" class="d-inline">
                            @csrf
                            @method('DELETE')
                            <button type="submit" class="btn btn-danger btn-sm"
                                onclick="return confirm('Tem certeza que deseja excluir a tarefa \'{{ addslashes($tarefa->titulo) }}\'?')">
                                Excluir
                            </button>
                        </form>
                    </td>
                </tr>
                @endforeach
            </tbody>
        </table>
        @endif
    </div>
</div>

@endsection
