@extends('layouts.app')

@section('content')

<div class="d-flex justify-content-between align-items-center mb-4">
    <h2>Editar Tarefa</h2>
    <a href="{{ route('tarefas.index') }}" class="btn btn-secondary">← Voltar</a>
</div>

<div class="card border-0 shadow-sm">
    <div class="card-body">

        {{-- Erros de validação --}}
        @if($errors->any())
            <div class="alert alert-danger">
                <ul class="mb-0">
                    @foreach($errors->all() as $error)
                        <li>{{ $error }}</li>
                    @endforeach
                </ul>
            </div>
        @endif

        <form action="{{ route('tarefas.update', $tarefa->id) }}" method="POST">
            @csrf
            @method('PUT')

            {{-- Título --}}
            <div class="mb-3">
                <label for="titulo" class="form-label fw-semibold">Título <span class="text-danger">*</span></label>
                <input
                    type="text"
                    name="titulo"
                    id="titulo"
                    class="form-control @error('titulo') is-invalid @enderror"
                    value="{{ old('titulo', $tarefa->titulo) }}"
                    placeholder="Digite o título da tarefa"
                >
                @error('titulo')
                    <div class="invalid-feedback">{{ $message }}</div>
                @enderror
            </div>

            {{-- Descrição --}}
            <div class="mb-3">
                <label for="descricao" class="form-label fw-semibold">Descrição</label>
                <textarea
                    name="descricao"
                    id="descricao"
                    class="form-control @error('descricao') is-invalid @enderror"
                    rows="3"
                    placeholder="Descrição detalhada (opcional)"
                >{{ old('descricao', $tarefa->descricao) }}</textarea>
                @error('descricao')
                    <div class="invalid-feedback">{{ $message }}</div>
                @enderror
            </div>

            <div class="row">
                {{-- Status --}}
                <div class="col-md-4 mb-3">
                    <label for="status" class="form-label fw-semibold">Status <span class="text-danger">*</span></label>
                    <select name="status" id="status" class="form-select @error('status') is-invalid @enderror">
                        <option value="">Selecione...</option>
                        <option value="pendente"     {{ old('status', $tarefa->status) === 'pendente'     ? 'selected' : '' }}>Pendente</option>
                        <option value="em_andamento" {{ old('status', $tarefa->status) === 'em_andamento' ? 'selected' : '' }}>Em Andamento</option>
                        <option value="concluida"    {{ old('status', $tarefa->status) === 'concluida'    ? 'selected' : '' }}>Concluída</option>
                    </select>
                    @error('status')
                        <div class="invalid-feedback">{{ $message }}</div>
                    @enderror
                </div>

                {{-- Prioridade --}}
                <div class="col-md-4 mb-3">
                    <label for="prioridade" class="form-label fw-semibold">Prioridade <span class="text-danger">*</span></label>
                    <select name="prioridade" id="prioridade" class="form-select @error('prioridade') is-invalid @enderror">
                        <option value="">Selecione...</option>
                        <option value="baixa" {{ old('prioridade', $tarefa->prioridade) === 'baixa' ? 'selected' : '' }}>Baixa</option>
                        <option value="media" {{ old('prioridade', $tarefa->prioridade) === 'media' ? 'selected' : '' }}>Média</option>
                        <option value="alta"  {{ old('prioridade', $tarefa->prioridade) === 'alta'  ? 'selected' : '' }}>Alta</option>
                    </select>
                    @error('prioridade')
                        <div class="invalid-feedback">{{ $message }}</div>
                    @enderror
                </div>

                {{-- Data Limite --}}
                <div class="col-md-4 mb-3">
                    <label for="data_limite" class="form-label fw-semibold">Data Limite</label>
                    <input
                        type="date"
                        name="data_limite"
                        id="data_limite"
                        class="form-control @error('data_limite') is-invalid @enderror"
                        value="{{ old('data_limite', $tarefa->data_limite ? $tarefa->data_limite->format('Y-m-d') : '') }}"
                    >
                    @error('data_limite')
                        <div class="invalid-feedback">{{ $message }}</div>
                    @enderror
                </div>
            </div>

            <div class="d-flex gap-2 mt-2">
                <button type="submit" class="btn btn-primary">Atualizar Tarefa</button>
                <a href="{{ route('tarefas.index') }}" class="btn btn-outline-secondary">Cancelar</a>
            </div>
        </form>

    </div>
</div>

@endsection
