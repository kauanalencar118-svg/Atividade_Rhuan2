@extends('layouts.app')

@section('content')

<div class="d-flex justify-content-between align-items-center mb-4">
    <h2>Cliente</h2>
    <a href="{{ route('clientes.create') }}" class="btn btn-primary"/>Novo</a>
</div>

<div class="card border-0 shadow-sm">
    <div class="card-body">
    <table class="table table-striped">
        <tr>
            <td>Nome</td>
            <td>Email</td>
            <td>telefone</td>
            <td width="180">Ação</td>
        </tr>
        @foreach($clientes as $cliente)
            <tr>
                <td>{{$cliente->nome}}</td>
                <td>{{$cliente->email}}</td>
                <td>{{$cliente->telefone}}</td>
                <td>
                    <a href="{{ route('clientes.edit', $cliente->id) }}" class="btn btn-warning btn-sm"/>Editar</a>

                    <form action="{{ route('clientes.destroy', $cliente->id) }}" method="POST" class="d-inline">
                        @csrf
                        @method('DELETE')
                        <button type="submit" class="btn btn-danger btn-sm">Excluir</button>
                    </form>
                </td>
            </tr>
        @endforeach
    </table>
       <!-- {{ $clientes->links() }} -->
    </div>
</div>

@endsection