@extends('layouts.app')

@section('content')

<div class="card border-0 shadow-sm">
    <div class="card-body">
    <h1 class="mb-4">Editar Cliente</h1>

    <form action="{{ route('clientes.update', $cliente->id) }}" method="post">
        @csrf
        @method('PUT')   
        <div class="mb-3">
            <label>Nome</label>
            <input type="text" name="nome" class="form-control" value="{{ $cliente->nome }}">
        </div>
        <div class="mb-3">
            <label>E-mail</label>
            <input type="email" name="email" class="form-control" value="{{ $cliente->email }}">
        </div>
        <div class="mb-3">
            <label>Telefone</label>
            <input type="text" name="telefone" class="form-control" value="{{ $cliente->telefone }}">
        </div>
        <button type="submit" class="btn btn-info">Atualizar</button>
    </form>

    </div>
</div>

@endsection
