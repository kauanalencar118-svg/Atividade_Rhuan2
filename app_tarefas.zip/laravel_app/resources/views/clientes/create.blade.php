@extends('layouts.app')

@section('content')

<div class="card border-0 shadow-sm">
    <div class="card-body">
    <h1 class="mb-4">Novo Cliente</h1>

    <form action="{{ route('clientes.store') }}" method="post">
        @csrf
        <div class="mb-3">
            <label>Nome</label>
            <input type="text" name="nome" class="form-control">
        </div>
        <div class="mb-3">
            <label>E-mail</label>
            <input type="email" name="email" class="form-control">
        </div>
        <div class="mb-3">
            <label>Telefone</label>
            <input type="text" name="telefone" class="form-control">
        </div>
        
        <button type="submit" class="btn btn-info">Salvar</button>
    </form>
    </div>
</div>

@endsection